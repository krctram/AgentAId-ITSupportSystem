﻿namespace Dataverse.Multilingual.Feedback.Models
{
    public class FeedbackViewModel
    {
        public string Rating { get; set; }
        public string Comment { get; set; }
        public string Title { get; set; }
        public string Msg { get; set; }
        public string Header { get; set; }
        public string Submit { get; set; }
        public string SubmitConfirm { get; set; }
    }
}
